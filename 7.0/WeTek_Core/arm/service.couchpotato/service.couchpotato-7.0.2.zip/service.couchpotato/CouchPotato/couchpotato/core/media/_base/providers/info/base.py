from couchpotato.core.media._base.providers.base import Provider


class BaseInfoProvider(Provider):
    type = 'unknown'
