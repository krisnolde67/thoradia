from couchpotato.core.media._base.providers.info.base import BaseInfoProvider


class MovieProvider(BaseInfoProvider):
    type = 'movie'
