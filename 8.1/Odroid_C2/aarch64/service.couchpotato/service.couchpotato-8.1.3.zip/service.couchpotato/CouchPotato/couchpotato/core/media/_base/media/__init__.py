from .main import MediaPlugin


def autoload():
    return MediaPlugin()
