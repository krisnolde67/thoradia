from .main import CategoryPlugin


def autoload():
    return CategoryPlugin()
